# CheckTime is a free software developed by Tommaso Fontana for Wurth Phoenix S.r.l. under GPL-2 License.


import numpy as np
from typing import Tuple

def BAYESIAN(x : np.ndarray, y : np.ndarray) -> Tuple[int, int]:
    # TODO
    m , q = 0, 0
    return m, q